
let carts = document.querySelectorAll('.add-cart');
    let products = [{
        name : 'The Ordinary',
        tag : 'theordinary',
        category : 'Skin',
        price : 14.00,
        inCart :0,
        image: 'theordinary.jpg'
        
        

    },
                    {
        name : 'Kiehl',
        tag : 'kiehl',
        price : 40.00,
        category : 'Skin',
        inCart :0,
        image: 'kiehl.jpg'
    },
                    {
        name : 'Isle of Paradise',
        tag : 'isleofparadise',
        category : 'Skin',
        price : 38,
        inCart :0,
        image: 'isleofparadise.jpg'                
    },
                    {
        name : 'LANEIGE',
        tag : 'laneige',
        category : 'Skin',
        price : 26,
        inCart :0,
        image: 'laneige.jpg'            
    },                  
    {
        name : 'Moroccanoil',
        tag : 'moroccanoil',
        price : 14.00,
        category : 'Hair',                               
        inCart :0,
        image: 'moroccanoil.jpg'
    },
                    {
        name : 'Amika',
        tag : 'amika',
        price : 130.00,
        category : 'Hair',                               
        inCart :0,
        image: 'amika.jpg'
    },
                    {
        name : 'Fenty Beauty',
        tag : 'fentybeauty',
        price : 25.00,
        category : 'Makeup',                               
        inCart :0,
        image: 'fentybeauty.jpg'                
    },
                    {
        name : 'Huda Beauty',
        tag : 'hudabeauty',
        price : 37.00,
        category : 'Makeup',                               
        inCart :0,
        image: 'hudabeauty.jpg'                
    },
                 {
        name : 'Glow Recipe',
        tag : 'glowrecipe',
        price : 37.00,
        category : 'Bath and Body',                               
        inCart :0,
        image: 'glowrecipe.jpg'             
    }, 
                {
        name : 'Body Oil',
        tag : 'bodyoil',
        price : 23.00,
        category : 'Bath and Body',                               
        inCart :0,
        image: 'bodyoil.jpg'            
    }, 
                             {
        name : 'Body Scrub',
        tag : 'bodyscrub',
        price : 26.00,
        category : 'bodyscrub',                               
        inCart :0,
        image: 'bb3.jpg'                         
    }, 
                                          {
        name : 'Pillowcase',
        tag : 'pillowcase',
        price : 140.00,
        category : 'Tools',                               
        inCart :0,
        image: 'pillowcase.jpg'                                      
    

    }]


    for (let i = 0; i < carts.length; i++){
    carts[i].addEventListener('click' , () => {
    cartNumbers(products[i]);
    totalCost(products[i]);
        //console.log(carts[i]);
    })
    }
    //because on refreshing it is becoming cart0 , to solve this create a function
    function onLoadCartNumbers(){
    let productNumbers = localStorage.getItem('cartNumbers');
        //console.log(cartNumbers);
    if(productNumbers){
    document.querySelector('.cart span').textContent = productNumbers;
    
    }
    }

    function cartNumbers(product, action){
    let productNumbers = localStorage.getItem('cartNumbers');
    productNumbers = parseInt(productNumbers);
        
     let cartItems = localStorage.getItem('productsInCart');   
         cartItems = JSON.parse(cartItems);
        if(action == "decrease"){
                localStorage.setItem('cartNumbers' , productNumbers - 1);
            document.querySelector('.cart span').textContent = productNumbers - 1;
        } else if(productNumbers){
                localStorage.setItem('cartNumbers' , productNumbers + 1);
            document.querySelector('.cart span').textContent = productNumbers + 1;
        }else{
               localStorage.setItem('cartNumbers' , 1);
        document.querySelector('.cart span').textContent = 1;}

    setItems(product);
    }

    function setItems(product){
    let cartItems = localStorage.getItem('productsInCart');
    //JSON into javascript object
    cartItems = JSON.parse(cartItems);
    if(cartItems != null){
    if(cartItems[product.tag] == undefined){
    cartItems = {
    ...cartItems,
    [product.tag]: product
    }
    }
    cartItems[product.tag].inCart += 1;
    } else {
    product.inCart = 1;
    cartItems = {
    [product.tag]: product

     }
    }
    //JSON.stringify - we need to pass not as javascript object but as JSON object into local storage
    localStorage.setItem("productsInCart", JSON.stringify(cartItems));
    }

    function totalCost(product, action){
    // console.log("price is ",product.price);
    let cartCost = localStorage.getItem('totalCost');
    if (action == "decrease"){
        cartCost = parseInt(cartCost);
        localStorage.setItem("totalCost", cartCost - product.price);
        
    } else  if(cartCost != null){
        cartCost = parseInt(cartCost);
        localStorage.setItem("totalCost",cartCost + product.price);

    }else{
        localStorage.setItem("totalCost", product.price);
    }
    }

    function displayCart(){
    let cartItems = localStorage.getItem("productsInCart");
    cartItems = JSON.parse(cartItems);
    let cartCost = localStorage.getItem('totalCost');
    let productContainer = document.querySelector(".products");
    //console.log(cartItems);
    if(cartItems && productContainer){
    productContainer.innerHTML = '';
    Object.values(cartItems).map(item => {
    productContainer.innerHTML += `<div class="product">
    <ion-icon name = "close-circle" ></ion-icon>  <img src="./images/${item.tag}.jpg"> <span>${item.name}</span></div> <div class="price">$${item.price}.00</div> <div class="quantity"> <ion-icon class="decrease" name="caret-back-circle-outline"></ion-icon></ion-icon><span>${item.inCart}</span> <ion-icon class ="increase" name="caret-forward-circle-outline"></ion-icon></div> <div class="total">$${item.inCart * item.price}.00 </div>`;
    });
    productContainer.innerHTML += 
        `<div class="basketTotalContainer"> <h4 class="basketTotalTitle">Basket Total</h4> <h4 class="basketTotal">$${cartCost}.00</h4>`;
    }
     deleteButtons();
     manageQuantity();        
    }

//var removeCartItemsButton = document.getElementsByClassName('delete-btn');
//console.log(removeCartItemsButton);

function deleteButtons(){
       let deleteButtons = document.querySelectorAll('.product ion-icon');
    let productName;
    let productNumbers = localStorage.getItem('cartNumbers');
    let cartItems = localStorage.getItem('productsInCart');
    cartItems = JSON.parse(cartItems); 
    let cartCost = localStorage.getItem('totalCost');
    
    for(let i=0; i<deleteButtons.length; i++ ){
        deleteButtons[i].addEventListener('click',() => {
        productName = deleteButtons[i].parentElement.textContent.trim().toLowerCase().replace(/ /g, '');
          
            localStorage.setItem('cartNumbers', productNumbers - cartItems[productName].inCart);
            
            localStorage.setItem('totalCost', cartCost - (cartItems[productName].price * cartItems[productName].inCart ));
            
            delete cartItems[productName];
            localStorage.setItem('productsInCart', JSON.stringify(cartItems));
            
            displayCart();
            onLoadCartNumbers();
        });
    }}
function manageQuantity(){
    let decreaseButtons = document.querySelectorAll('.decrease');
    let increaseButtons = document.querySelectorAll('.increase');
        let cartItems = localStorage.getItem('productsInCart');
    cartItems = JSON.parse(cartItems); 
    let currentQuantity = 0;
    let currentProduct = "";
    console.log(cartItems);
    
    for (let i = 0; i< decreaseButtons.length; i++){
        decreaseButtons[i].addEventListener('click',() => {
            currentQuantity = decreaseButtons[i].parentElement.querySelector('span').textContent;
            console.log(currentQuantity);
            currentProduct = decreaseButtons[i].parentElement.previousElementSibling.previousElementSibling.querySelector('span').textContent.trim().toLowerCase().replace(/ /g, ''); 
            console.log(currentProduct);
            
            if(cartItems[currentProduct].inCart > 1){
            cartItems[currentProduct].inCart -= 1;
                cartNumbers(cartItems[currentProduct], "decrease");
                totalCost(cartItems[currentProduct], "decrease");
            localStorage.setItem('productsInCart', JSON.stringify(cartItems));
            displayCart();}
        });
    }
       for (let i = 0; i< increaseButtons.length; i++){
        increaseButtons[i].addEventListener('click',() => {
               currentQuantity = increaseButtons[i].parentElement.querySelector('span').textContent;
            console.log(currentQuantity);
            
            currentProduct = increaseButtons[i].parentElement.previousElementSibling.previousElementSibling.querySelector('span').textContent.trim().toLowerCase().replace(/ /g, ''); 
            console.log(currentProduct);
            
          
            cartItems[currentProduct].inCart += 1;
                cartNumbers(cartItems[currentProduct]);
                totalCost(cartItems[currentProduct]);
            localStorage.setItem('productsInCart', JSON.stringify(cartItems));
            displayCart();
            
        });
    }   
}
  


/*search */
const charactersList = document.getElementById('sortProducts');
const searchBar = document.getElementById('searchBar');
let newProducts = products;
//console.log(products);
if(searchBar != null){
searchBar.addEventListener('keyup', (e) => {
    const searchString = e.target.value.toLowerCase();

    const filteredCharacters = newProducts.filter((character) => {
        return (
            character.name.toLowerCase().includes(searchString) ||
            character.category.toLowerCase().includes(searchString)
        );
    });
    let sortcontainer = document.querySelector(".sortproducts")
        sortcontainer.innerHTML = '';
    Object.values(filteredCharacters).map(item => {
        sortcontainer.innerHTML +=  `<div class = "image" >
        <img src="./images/${item.tag}.jpg"><a class="add-cart cart1" href= "#">Add Cart</a>
<div class = "description"> ${item.name} <div> ${item.category}<div>$${item.price}.00</div></div></div></div>`;
    });
});

}



 
    
 
    

 function sortLowToHigh(){
       
     products.sort((a,b) => (a.price > b.price ? 1 : -1));
     var newProducts = products;
   
         let sortcontainer = document.querySelector(".sortproducts")
     if(sortcontainer){
         sortcontainer.innerHTML = '';
    Object.values(newProducts).map(item => {
        sortcontainer.innerHTML +=  `<div class = "image">
        <img src="./images/${item.tag}.jpg"><a class="add-cart cart1" href= "#">Add Cart</a>
<div class = "description"> ${item.name} <div> ${item.category}<div>$${item.price}.00</div></div></div></div>`;
    });
  
    }
     
 }
 function sortHighToLow(){
     products.sort((a,b) => (a.price < b.price ? 1 : -1));
    var newProducts = products;
         let sortcontainer = document.querySelector(".sortproducts")
     if(sortcontainer){
         sortcontainer.innerHTML = '';
    Object.values(newProducts).map(item => {
        sortcontainer.innerHTML +=  `<div class = "image">
        <img src="./images/${item.tag}.jpg">
<a class="add-cart cart1" href= "#">Add Cart</a><div class = "description"> ${item.name} <div> ${item.category}<div>$${item.price}.00</div></div></div></div> `;
    });
  
    }
 
 }

function sortBySkin(){
    let skinArray = [];
   
    for (let i =0; i <products.length; i++){
        if(products[i].category == "Skin"){
            skinArray.push(products[i]);
        }
    }
         let sortcontainer = document.querySelector(".sortproducts")
     if(sortcontainer){
         sortcontainer.innerHTML = '';
    Object.values(skinArray).map(item => {
        sortcontainer.innerHTML +=  `<div class = "image">
        <img src="./images/${item.tag}.jpg"><a class="add-cart cart1" href= "#">Add Cart</a><div class = "description"> ${item.name} <div> ${item.category}<div>$${item.price}.00</div></div></div></div> `;
    });
  
    }
}
function sortByHair(){
        let hairArray = [];
   
    for (let i =0; i <products.length; i++){
        if(products[i].category == "Hair"){
            hairArray.push(products[i]);
        }
    }
         let sortcontainer = document.querySelector(".sortproducts")
     if(sortcontainer){
         sortcontainer.innerHTML = '';
    Object.values(hairArray).map(item => {
        sortcontainer.innerHTML +=  `<div class = "image">
        <img src="./images/${item.tag}.jpg"><a class="add-cart cart1" href= "#">Add Cart</a><div class = "description"> ${item.name} <div> ${item.category}<div>$${item.price}.00</div></div></div></div> `;
    });
  
    }
}
function sortByMakeUp(){
        let MakeUpArray = [];
   
    for (let i =0; i <products.length; i++){
        if(products[i].category == "Makeup"){
            MakeUpArray.push(products[i]);
        }
    }
         let sortcontainer = document.querySelector(".sortproducts")
     if(sortcontainer){
         sortcontainer.innerHTML = '';
    Object.values(MakeUpArray).map(item => {
        sortcontainer.innerHTML += `<div class = "image">
        <img src="./images/${item.tag}.jpg"><a class="add-cart cart1" href= "#">Add Cart</a><div class = "description"> ${item.name} <div> ${item.category}<div>$${item.price}.00</div></div></div></div> `;
    });
  
    }
}

function sortByBb(){
        let BbArray = [];
   
    for (let i =0; i <products.length; i++){
        if(products[i].category == "Bath and Body"){
            BbArray.push(products[i]);
        }
    }
         let sortcontainer = document.querySelector(".sortproducts")
     if(sortcontainer){
         sortcontainer.innerHTML = '';
    Object.values(BbArray).map(item => {
        sortcontainer.innerHTML +=  `<div class = "image">
        <img src="./images/${item.tag}.jpg"><a class="add-cart cart1" href= "#">Add Cart</a><div class = "description"> ${item.name} <div> ${item.category}<div>$${item.price}.00</div></div></div></div> `;
    });
  
    }
}
function sortByTools(){
        let tArray = [];
   
    for (let i =0; i <products.length; i++){
        if(products[i].category == "Tools"){
            tArray.push(products[i]);
        }
    }
         let sortcontainer = document.querySelector(".sortproducts")
     if(sortcontainer){
         sortcontainer.innerHTML = '';
    Object.values(tArray).map(item => {
        sortcontainer.innerHTML +=   `<div class = "image">
        <img src="./images/${item.tag}.jpg"><a class="add-cart cart1" href= "#">Add Cart</a><div class = "description"> ${item.name} <div> ${item.category}<div>$${item.price}.00</div></div></div></div> `;
    });
  
    }
}

    function sortAll(){
                 let sortcontainer = document.querySelector(".sortproducts")
     if(sortcontainer){
         sortcontainer.innerHTML = '';
    Object.values(products).map(item => {
        sortcontainer.innerHTML += `<div class = "image">
        <img src="./images/${item.tag}.jpg"><a class="add-cart cart1" href= "#">Add Cart</a><div class = "description"> ${item.name} <div> ${item.category}<div>$${item.price}.00</div></div></div></div> `;
    });
  
    }
    }



    onLoadCartNumbers();
    displayCart();



             function GetSelectedTextValue(prices) 
             {
        var selectedText = prices.options[prices.selectedIndex].innerHTML;
        var selectedValue = prices.value;
                 if (selectedValue == 0){
        sortHighToLow();
                     
                 }
                 else{
                     sortLowToHigh();
                 }
    }


             function GetValue(categories) 
             {
        var selectedText = categories.options[categories.selectedIndex].innerHTML;
        var selectedValue = categories.value;
                 if (selectedValue == 2){
      
                     sortAll();
                 }
                 else if (selectedValue == 3){
                   sortBySkin();
                     
                 }
                  else if (selectedValue == 4){
                   sortByHair();
                 }
                  else if (selectedValue == 5){
                   sortByMakeUp();
                 }
                  else if (selectedValue == 6){
                   sortByBb();
                 }
                 else{
                     sortByTools();
                 }
    }


         